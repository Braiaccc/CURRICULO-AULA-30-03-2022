// Definição da interface Voador
public interface Voador {
    void decolar();
    void voar();
    void aterrar();
}

