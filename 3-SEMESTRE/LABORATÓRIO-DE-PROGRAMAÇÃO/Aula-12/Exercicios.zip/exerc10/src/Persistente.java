// Definição da interface Persistente
public interface Persistente {
    void salvar();
    void atualizar();
    void deletar();
    void buscar();
}

