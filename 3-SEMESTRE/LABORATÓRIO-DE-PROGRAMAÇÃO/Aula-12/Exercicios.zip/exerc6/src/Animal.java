// Definição da interface Animal
public interface Animal {
    void comer();
    void dormir();
}

