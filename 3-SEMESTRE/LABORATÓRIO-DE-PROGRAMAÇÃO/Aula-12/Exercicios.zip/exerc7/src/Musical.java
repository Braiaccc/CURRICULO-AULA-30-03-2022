// Definição da interface Musical
public interface Musical {
    void tocar();
    void parar();
    void pausar();
}

