// Definição da interface Corredor
public interface Corredor {
    void correr();
}
