// Definição da interface Andador
public interface Andador {
    void andar();
}

