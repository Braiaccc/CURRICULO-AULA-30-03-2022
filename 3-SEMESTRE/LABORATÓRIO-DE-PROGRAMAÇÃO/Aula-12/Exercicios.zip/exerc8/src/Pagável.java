// Definição da interface Pagável
public interface Pagável {
    void pagar();
    void verificarPagamento();
}

