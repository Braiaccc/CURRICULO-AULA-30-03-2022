// Definição da interface Descarregável
public interface Descarregável {
    void carga();
}

