// Definição da interface Carregável
public interface Carregável {
    void carga();
}
