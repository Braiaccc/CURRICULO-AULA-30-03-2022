// Definição da interface FormaGeometrica
public interface FormaGeometrica {
    double calcularArea();
    double calcularPerimetro();
}

