public interface Treinavel {
    void realizarTruque();
}
