package br.com.ulbra.apicomretrofit.data

data class Character(val name: String, val image: String)
