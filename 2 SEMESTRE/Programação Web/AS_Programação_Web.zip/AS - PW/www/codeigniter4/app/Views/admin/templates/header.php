<!DOCTYPE html>
<html lang="pt-br">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>

	<!-- bootstrap    -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

	<!-- JS e CSS -->
	<script src="assets/js/script.js"></script>
	<link rel="stylesheet" href="assets/css/style.css">
	<link href="https://fonts.googleapis.com/css2?family=Noto+Serif+Display:wght@400;600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/9ad701c2b9.js" crossorigin="anonymous"></script>
</head>
<body>
	<style>
		*{
			
		}
		header{
			font-family: "Times New Roman", Times, serif;
			font-weight:600;
			border-bottom:solid 1px black;
			text-align:center;			
		}
		header nav{
			display:flex;
			justify-content:center;
			align-items:center;
			margin-left:-80px;
		}
		header nav ul li{
			margin:0 50px;
			cursor:pointer;
		}

		header i{
			color:white;
			cursor:pointer;
		}
		#menu{
			font-family: "Times New Roman", Times, serif;
			font-weight:600;
			padding-bottom:30% ;	
		}
		#menu a{
			color:white;
		}

		footer{
			border-top: solid 1px black;
			position: absolute;
			bottom: 0;
			color: #FFF;
			width: 100%;	

		}
	</style>

	<header class="container-fluid bg-dark p-4 text-white text-center">
		<nav>
			<ul class="nav navbar-expand-lg">
				<li class="nav-item">
					<h1>AsWork</h1>
				</li>				
			</ul>
		</nav>
	</header>
	<div class="container-fluid">
		<div class="row">
			<nav  id='menu' class="bg-secondary text-white col-md-3 p-6">
				<h3>Menu</h3>
				<ul class="nav flex-column">
					<li class="nav-item">
						<a id="btnHome" class="nav-link" href="<?=base_url('/admin')?>">Home</a>
					</li>
				
				<h3>Clientes</h3>
				<ul class="nav flex-column">
					<li class="nav-item">
						<a id="" class="nav-link" href="<?=base_url('/admin/insertClient')?>">Cadastro</a>
					</li>
					<li class="nav-item">
						<a id="" class="nav-link" href="<?=base_url('/admin/listClients')?>">Lista de Clientes</a>
					</li>
					<li class="nav-item">
						<a id="" class="nav-link" href="<?=base_url('/admin/listContacts')?>">Lista de Contatos</a>
					</li>
					<li class="nav-item">
						<a id="btnHome" class="nav-link" href="<?=base_url('/api/client')?>">API</a>
					</li>
				</ul>
				</ul>
			</nav>
			<section class="col-md-9 p-5">